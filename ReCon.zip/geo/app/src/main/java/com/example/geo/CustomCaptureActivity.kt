package com.example.geo

import android.hardware.Camera
import android.os.Bundle
import com.journeyapps.barcodescanner.CaptureActivity

class CustomCaptureActivity : CaptureActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            val camera = Camera.open()  // Open the camera
            val params = camera.parameters
            params.focusMode = Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE // Continuous focus
            camera.parameters = params
        } catch (e: Exception) {
            e.printStackTrace()  // Print errors if the camera fails
        }
    }
}