package com.example.geo

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.journeyapps.barcodescanner.CaptureActivity
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity : AppCompatActivity() {

    private lateinit var scanQrBtn: Button
    private lateinit var scannedValueTv: TextView

    private val scannerLauncher = registerForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            scannedValueTv.text = "Scanned Value: ${result.contents}"
        } else {
            Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scanQrBtn = findViewById(R.id.scanQrBtn)
        scannedValueTv = findViewById(R.id.scannedValueTv)

        registerUIListener()
    }

    private fun registerUIListener() {
        scanQrBtn.setOnClickListener {
            val options = ScanOptions().apply {
                setPrompt("Align the QR code within the frame")
                setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                setBeepEnabled(true)
                  setBarcodeImageEnabled(true)  // Saves barcode image
                setOrientationLocked(false)  // Allow rotation for better focus
                setCaptureActivity(CustomCaptureActivity::class.java) // Use Custom Capture
            }
            scannerLauncher.launch(options)
        }
    }

}
